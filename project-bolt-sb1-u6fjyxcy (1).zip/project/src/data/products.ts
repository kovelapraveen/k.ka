export const products = [
  // Vegetables
  {
    id: 'v1',
    name: 'Fresh Tomatoes',
    description: 'Locally grown, organic tomatoes',
    price: 40,
    category: 'vegetables',
    image: 'https://images.unsplash.com/photo-1546470427-1ec6068c9ce4?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'v2',
    name: 'Spinach',
    description: 'Fresh organic spinach leaves',
    price: 30,
    category: 'vegetables',
    image: 'https://images.unsplash.com/photo-1576045057995-568f588f82fb?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'v3',
    name: 'Carrots',
    description: 'Sweet and crunchy organic carrots',
    price: 35,
    category: 'vegetables',
    image: 'https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?auto=format&fit=crop&w=800&q=80'
  },

  // Fruits
  {
    id: 'f1',
    name: 'Fresh Mangoes',
    description: 'Sweet and juicy mangoes',
    price: 120,
    category: 'fruits',
    image: 'https://images.unsplash.com/photo-1553279768-865429fa0078?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'f2',
    name: 'Bananas',
    description: 'Ripe organic bananas',
    price: 60,
    category: 'fruits',
    image: 'https://images.unsplash.com/photo-1603833665858-e61d17a86224?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'f3',
    name: 'Apples',
    description: 'Fresh red apples',
    price: 80,
    category: 'fruits',
    image: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?auto=format&fit=crop&w=800&q=80'
  },

  // Non-Veg
  {
    id: 'nv1',
    name: 'Chicken Breast',
    description: 'Fresh boneless chicken breast',
    price: 220,
    category: 'nonveg',
    image: 'https://images.unsplash.com/photo-1604503468506-a8da13d82791?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'nv2',
    name: 'Mutton',
    description: 'Fresh cut mutton pieces',
    price: 450,
    category: 'nonveg',
    image: 'https://images.unsplash.com/photo-1603048297172-c84c8583dde3?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'nv3',
    name: 'Eggs',
    description: 'Farm fresh eggs',
    price: 90,
    category: 'nonveg',
    image: 'https://images.unsplash.com/photo-1506976785307-8732e854ad03?auto=format&fit=crop&w=800&q=80'
  },

  // Seafood
  {
    id: 's1',
    name: 'Fresh Prawns',
    description: 'Clean and fresh prawns',
    price: 350,
    category: 'seafood',
    image: 'https://images.unsplash.com/photo-1565680018434-b513d5e5fd47?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 's2',
    name: 'Fish',
    description: 'Fresh water fish',
    price: 280,
    category: 'seafood',
    image: 'https://images.unsplash.com/photo-1544943910-4c1dc44aab44?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 's3',
    name: 'Crab',
    description: 'Fresh sea crab',
    price: 400,
    category: 'seafood',
    image: 'https://images.unsplash.com/photo-1559737558-2f5a35f4523b?auto=format&fit=crop&w=800&q=80'
  }
];